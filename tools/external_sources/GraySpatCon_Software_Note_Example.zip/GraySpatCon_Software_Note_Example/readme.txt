This original version of this archive is available at the URL:
https://github.com/ec-jrc/GWB/tree/main/tools/external_sources

This location contains:
- GraySpatCon.c: source code of GraySpatCon
- grayspatcon_lin64, grayspatcon_mac, grayspatcon64.exe: operating system specific 64bit executables 
- GRAYSPATCON_Guide.pdf: user manual of GraySpatCon

Please check this URL for a potential updated version of this archive.

This archive contains the following files:
- GraySpatCon_*.R: operating system specific R-script 
- *.tif: example GeoTIFF input maps that can be used with GraySpatCon

Note: 
please read through the R-script and amend as needed.
Running the R-scripts requires using the operating system specific GraySpatCon binary. 
Make sure it is executable and located in the R working directory.

Please read the GRAYSPATCON_Guide.pdf for further instructions.
