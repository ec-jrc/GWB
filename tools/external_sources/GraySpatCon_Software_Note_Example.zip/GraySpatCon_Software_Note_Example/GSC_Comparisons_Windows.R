# ***************script to compare with other R packages**************
# The execution times reported in the Software Note are based on this platform:
# Windows10(x64).Dual quad-core Xeon E5-1620 @ 3.7GHz, 64GB RAM.
# RStudio 2022.02.1+461 "Prairie Trillium" 
# R version 4.1.3 (2022-03-10) "One Push-Up"; packages updated April 10, 2023
#
library(sp)
library(raster)
library(gdalUtilities)

workdir <- "E:/PxPxxWork/Rtesting"    # specify working directory
# input data image 
gscinput_tif <- "gscinput.tif"        # tif with pixel values in [0, 100] with 255=missing. 1990x1289 pixels

#
# Package: glcm (single-core) 
library(glcm)
# Re-create input image files

R0 <- raster(gscinput_tif)  # for glcm
plot(R0)
# Metric "homogeneity" and 31x31 window size
start_time <- Sys.time()
glcm_homogeneity <-   # shift 0,-1 and 1,0 is one down and one right, like GraySpatCon
  glcm(R0, n_grey = 101, window = c(31, 31), shift = list(c(0,-1), c(1,0)),
       # statistics = c("mean", "variance", "homogeneity", "contrast",
       #               "dissimilarity", "entropy", "second_moment", "correlation"),
       statistics = c("homogeneity"),
       min_x=NULL, max_x=NULL, na_opt="any", na_val=NA, scale_factor=1, asinteger=FALSE)
end_time <- Sys.time()
end_time - start_time
# execution time1 is 3.67 minutes
# execution time2 is 3.80 minutes
# execution time2 is 3.63 minutes
plot(glcm_homogeneity) # note the output image is trimmed -- glcm produces missing data where a  window contains any missing data.

# Metric "entropy" and 31x31 window size
start_time <- Sys.time()
glcm_entropy <-   # shift 0,-1 and 1,0 is one down and one right, like GraySpatCon
  glcm(R0, n_grey = 101, window = c(31, 31), shift = list(c(0,-1), c(1,0)),
       # statistics = c("mean", "variance", "homogeneity", "contrast",
       #               "dissimilarity", "entropy", "second_moment", "correlation"),
       statistics = c("entropy"),
       min_x=NULL, max_x=NULL, na_opt="any", na_val=NA, scale_factor=1, asinteger=FALSE)
end_time <- Sys.time()
end_time - start_time
# execution time1 is 4.92 minutes
# execution time2 is 4.80 minutes
# execution time2 is 4.98 minutes
plot(glcm_entropy) # note the output image is trimmed -- glcm produces missing data where a  window contains any missing data.


# Metric "contrast" and 31x31 window size
start_time <- Sys.time()
glcm_contrast <-   # shift 0,-1 and 1,0 is one down and one right, like GraySpatCon
  glcm(R0, n_grey = 101, window = c(31, 31), shift = list(c(0,-1), c(1,0)),
       # statistics = c("mean", "variance", "homogeneity", "contrast",
       #               "dissimilarity", "entropy", "second_moment", "correlation"),
       statistics = c("contrast"),
       min_x=NULL, max_x=NULL, na_opt="any", na_val=NA, scale_factor=1, asinteger=FALSE)
end_time <- Sys.time()
end_time - start_time
# execution time1 is 3.09 minutes
# execution time2 is 3.19 minutes
# execution time2 is 3.07 minutes
plot(glcm_contrast) # note the output image is trimmed -- glcm produces missing data where a  window contains any missing data.

# Metric "second moment" and 31x31 window size
start_time <- Sys.time()
glcm_second_moment <-   # shift 0,-1 and 1,0 is one down and one right, like GraySpatCon
  glcm(R0, n_grey = 101, window = c(31, 31), shift = list(c(0,-1), c(1,0)),
       # statistics = c("mean", "variance", "homogeneity", "contrast",
       #               "dissimilarity", "entropy", "second_moment", "correlation"),
       statistics = c("second_moment"),
       min_x=NULL, max_x=NULL, na_opt="any", na_val=NA, scale_factor=1, asinteger=FALSE)
end_time <- Sys.time()
end_time - start_time
# execution time1 is 2.91 minutes
# execution time2 is 2.89 minutes
# execution time2 is 2.99 minutes
plot(glcm_second_moment) # note the output image is trimmed -- glcm produces missing data where a  window contains any missing data.


#Package: fastGLCM (multi-core) with the metric "homogeneity", kernel_size 31 (x31) "levels" = 8 (per manual)
library(fastGLCM)
library(OpenImageR)
library(utils)

setwd(workdir)
im = readImage("gscinput.tif")  # Note openImageR does not recognize tags needed for geoTIFF support
# use openImageR functions to get correct image format
dims <- dim(im)
im=resizeImage(im,dims[1],dims[2],'nearest')
im=OpenImageR::norm_matrix_range(im,0,255)
imageShow(im)
#methods=c('mean', 'std', 'contrast', 'dissimilarity', 'homogeneity', 'ASM', 'energy', 'max', 'entropy')
methods=c('homogeneity')
start_time <- Sys.time()
res_glcm = fastGLCM_Rcpp(data = im, methods = methods, levels = 8, kernel_size = 31,
                         distance = 1.0, angle = 0.0,  threads = 8, verbose = TRUE)  # set threads to 8 or 1 core
end_time <- Sys.time()
end_time - start_time
# 8-core:
# execution time1 is 27.53 seconds
# execution time2 is 26.90 seconds
# execution time2 is 27.88 seconds
# 1-core
# execution time1 is 1.62 minutes
# execution time2 is 1.63 minutes
# execution time3 is 1.61 minutes

str(res_glcm) # plotting seems to work only if all metrics are selected
plot_multi_images(list_images = res_glcm, par_ROWS = 1, par_COLS = 1, titles = methods)



# fastGLCM metric entropy
setwd(workdir)
im = readImage("gscinput.tif")  # Note openImageR does not recognize tags needed for geoTIFF support
# use openImageR functions to get correct image format
dims <- dim(im)
im=resizeImage(im,dims[1],dims[2],'nearest')
im=OpenImageR::norm_matrix_range(im,0,255)
imageShow(im)
#methods=c('mean', 'std', 'contrast', 'dissimilarity', 'homogeneity', 'ASM', 'energy', 'max', 'entropy')
methods=c('entropy')
start_time <- Sys.time()
res_glcm = fastGLCM_Rcpp(data = im, methods = methods, levels = 8, kernel_size = 31,
                         distance = 1.0, angle = 0.0,  threads = 8, verbose = TRUE)  # set threads to 8 or 1 core
end_time <- Sys.time()
end_time - start_time
# 8-core:
# execution time1 is 27.5 seconds
# execution time2 is 29.4 seconds
# execution time3 is 26.6 seconds
# 1-core
# execution time1 is 1.66 minutes
# execution time2 is 1.65 minutes
# execution time3 is 1.69 minutes

str(res_glcm)# plotting seems to work only if all metrics are selected
plot_multi_images(list_images = res_glcm, par_ROWS = 1, par_COLS = 1, titles = methods)

# fastGLCM metric contrast
setwd(workdir)
im = readImage("gscinput.tif")  # Note openImageR does not recognize tags needed for geoTIFF support
# use openImageR functions to get correct image format
dims <- dim(im)
im=resizeImage(im,dims[1],dims[2],'nearest')
im=OpenImageR::norm_matrix_range(im,0,255)
imageShow(im)
#methods=c('mean', 'std', 'contrast', 'dissimilarity', 'homogeneity', 'ASM', 'energy', 'max', 'entropy')
methods=c('contrast')
start_time <- Sys.time()
res_glcm = fastGLCM_Rcpp(data = im, methods = methods, levels = 8, kernel_size = 31,
                         distance = 1.0, angle = 0.0,  threads = 1, verbose = TRUE)  # set threads to 8 or 1 core
end_time <- Sys.time()
end_time - start_time
# 8-core:
# execution time1 is 26.89 seconds
# execution time2 is 27.51 seconds
# execution time3 is 26.38 seconds
# 1-core
# execution time1 is 1.57 minutes
# execution time2 is 1.56 minutes
# execution time3 is 1.59 minutes

str(res_glcm)# plotting seems to work only if all metrics are selected
plot_multi_images(list_images = res_glcm, par_ROWS = 1, par_COLS = 1, titles = methods)

# fastGLCM metric ASM
setwd(workdir)
im = readImage("gscinput.tif")  # Note openImageR does not recognize tags needed for geoTIFF support
# use openImageR functions to get correct image format
dims <- dim(im)
im=resizeImage(im,dims[1],dims[2],'nearest')
im=OpenImageR::norm_matrix_range(im,0,255)
imageShow(im)
#methods=c('mean', 'std', 'contrast', 'dissimilarity', 'homogeneity', 'ASM', 'energy', 'max', 'entropy')
methods=c('ASM')
start_time <- Sys.time()
res_glcm = fastGLCM_Rcpp(data = im, methods = methods, levels = 8, kernel_size = 31,
                         distance = 1.0, angle = 0.0,  threads = 8, verbose = TRUE)  # set threads to 8 or 1 core
end_time <- Sys.time()
end_time - start_time
# 8-core:
# execution time1 is 27.14 seconds
# execution time2 is 25.93 seconds
# execution time3 is 26.03 seconds
# 1-core
# execution time1 is 1.57 minutes
# execution time2 is 1.53 minutes
# execution time3 is 1.56 minutes

str(res_glcm)# plotting seems to work only if all metrics are selected
plot_multi_images(list_images = res_glcm, par_ROWS = 1, par_COLS = 1, titles = methods)




# GraySpatCon (single- and eight-core) for metric 32 (homogeneity) in 31x31 window
#   GSC uses all available cores; un-comment the following line for single-core comparison
#     Sys.setenv("OMP_NUM_THREADS" = 1)
#   Be sure to later run the following line to restore multi-core usage
#     Sys.unsetenv("OMP_NUM_THREADS")
setwd(workdir)  # see top of script
gscinput_tif <- "gscinput.tif"  # tif with pixel values in [0, 100] with 255=missing. 1990x1289 pixels
R0 <- raster(gscinput_tif)
gdal_translate(gscinput_tif, "gscinput", of="ENVI") # for GraySpatCon

# create parameter file to duplicate the glcm run
file.remove("gscpars.txt") # delete existing parameter file
fileConn <- file("gscpars.txt", "a") # create file connection for appending
writeLines(sprintf("R %d", nrow(R0)), fileConn)
writeLines(sprintf("C %d", ncol(R0)), fileConn)
writeLines(c("F 2", "M 32","G 0", "P 0", "W 31", "A 1", "B 5", "X 88", "Y 87", "K 5"), fileConn)
close(fileConn)

start_time <- Sys.time()
system("grayspatcon64.exe")
end_time <- Sys.time()
end_time - start_time
# 8-core:
# execution time1 is 3.99 seconds
# execution time2 is 4.10 seconds
# execution time3 is 4.11 seconds
# 1-core:
# execution time1 is 16.49 seconds
# execution time2 is 17.38 seconds
# execution time3 is 17.62 seconds

# rename output file
old <- c("gscoutput")
new <- c("gscoutput.bsq")
file.rename(old, new)
# copy and edit old header file.
oldhdr <- readLines("gscinput.hdr")
newhdr <- gsub(pattern = "data type = 1", replace = "data type = 4", x = oldhdr)
writeLines(newhdr, "gscoutput.hdr")
# plot the output
R1 <- raster("gscoutput.bsq")
plot(R1)

# GraySpatCon (single- and eight-core) for metric 4 (EntropyOrderedAdj) in 31x31 window
#   GSC uses all available cores; un-comment the following line for single-core comparison
#     Sys.setenv("OMP_NUM_THREADS" = 1)
#   Be sure to later run the following line to restore multi-core usage
#     Sys.unsetenv("OMP_NUM_THREADS")
setwd(workdir)  # see top of script
gscinput_tif <- "gscinput.tif"  # tif with pixel values in [0, 100] with 255=missing. 1990x1289 pixels
R0 <- raster(gscinput_tif)
gdal_translate(gscinput_tif, "gscinput", of="ENVI") # for GraySpatCon

# create parameter file to duplicate the glcm run
file.remove("gscpars.txt") # delete existing parameter file
fileConn <- file("gscpars.txt", "a") # create file connection for appending
writeLines(sprintf("R %d", nrow(R0)), fileConn)
writeLines(sprintf("C %d", ncol(R0)), fileConn)
writeLines(c("F 2", "M 4","G 0", "P 0", "W 31", "A 1", "B 5", "X 88", "Y 87", "K 5"), fileConn)
close(fileConn)

start_time <- Sys.time()
system("grayspatcon64.exe")
end_time <- Sys.time()
end_time - start_time
# 8-core:
# execution time1 is 10.44 seconds
# execution time2 is 10.33 seconds
# execution time3 is 10.88 seconds
# 1-core:
# execution time1 is 50.06 seconds
# execution time2 is 46.53 seconds
# execution time3 is 48.26 seconds

# rename output file
old <- c("gscoutput")
new <- c("gscoutput.bsq")
file.rename(old, new)
# copy and edit old header file.
oldhdr <- readLines("gscinput.hdr")
newhdr <- gsub(pattern = "data type = 1", replace = "data type = 4", x = oldhdr)
writeLines(newhdr, "gscoutput.hdr")
# plot the output
R1 <- raster("gscoutput.bsq")
plot(R1)

# GraySpatCon (single- and eight-core) for metric 29 (Contrast) in 31x31 window
#   GSC uses all available cores; un-comment the following line for single-core comparison
#     Sys.setenv("OMP_NUM_THREADS" = 1)
#   Be sure to later run the following line to restore multi-core usage
#     Sys.unsetenv("OMP_NUM_THREADS")
setwd(workdir)  # see top of script
gscinput_tif <- "gscinput.tif"  # tif with pixel values in [0, 100] with 255=missing. 1990x1289 pixels
R0 <- raster(gscinput_tif)
gdal_translate(gscinput_tif, "gscinput", of="ENVI") # for GraySpatCon

# create parameter file to duplicate the glcm run
file.remove("gscpars.txt") # delete existing parameter file
fileConn <- file("gscpars.txt", "a") # create file connection for appending
writeLines(sprintf("R %d", nrow(R0)), fileConn)
writeLines(sprintf("C %d", ncol(R0)), fileConn)
writeLines(c("F 2", "M 29","G 0", "P 0", "W 31", "A 1", "B 5", "X 88", "Y 87", "K 5"), fileConn)
close(fileConn)

start_time <- Sys.time()
system("grayspatcon64.exe")
end_time <- Sys.time()
end_time - start_time
# 8-core:
# execution time1 is 4.14 seconds
# execution time2 is 4.34 seconds
# execution time3 is 4.23 seconds
# 1-core:
# execution time1 is 17.61 seconds
# execution time2 is 17.47 seconds
# execution time3 is 17.46 seconds

# rename output file
old <- c("gscoutput")
new <- c("gscoutput.bsq")
file.rename(old, new)
# copy and edit old header file.
oldhdr <- readLines("gscinput.hdr")
newhdr <- gsub(pattern = "data type = 1", replace = "data type = 4", x = oldhdr)
writeLines(newhdr, "gscoutput.hdr")
# plot the output
R1 <- raster("gscoutput.bsq")
plot(R1)


# GraySpatCon (single- and eight-core) for metric 14 (DiversityOrderedAdj) in 31x31 window
#
####  note this metric equals 1 minus ASM so output map legend will be flipped compared to glcm and fastGLCM
#
#   GSC uses all available cores; un-comment the following line for single-core comparison
#     Sys.setenv("OMP_NUM_THREADS" = 1)
#   Be sure to later run the following line to restore multi-core usage
#     Sys.unsetenv("OMP_NUM_THREADS")
setwd(workdir)  # see top of script
gscinput_tif <- "gscinput.tif"  # tif with pixel values in [0, 100] with 255=missing. 1990x1289 pixels
R0 <- raster(gscinput_tif)
gdal_translate(gscinput_tif, "gscinput", of="ENVI") # for GraySpatCon

# create parameter file to duplicate the glcm run
file.remove("gscpars.txt") # delete existing parameter file
fileConn <- file("gscpars.txt", "a") # create file connection for appending
writeLines(sprintf("R %d", nrow(R0)), fileConn)
writeLines(sprintf("C %d", ncol(R0)), fileConn)
writeLines(c("F 2", "M 14","G 0", "P 0", "W 31", "A 1", "B 5", "X 88", "Y 87", "K 5"), fileConn)
close(fileConn)

start_time <- Sys.time()
system("grayspatcon64.exe")
end_time <- Sys.time()
end_time - start_time
# 8-core:
# execution time1 is 4.16 seconds
# execution time2 is 3.99 seconds
# execution time3 is 4.00 seconds
# 1-core:
# execution time1 is 16.42 seconds
# execution time2 is 17.59 seconds
# execution time3 is 16.83 seconds

# rename output file
old <- c("gscoutput")
new <- c("gscoutput.bsq")
file.rename(old, new)
# copy and edit old header file.
oldhdr <- readLines("gscinput.hdr")
newhdr <- gsub(pattern = "data type = 1", replace = "data type = 4", x = oldhdr)
writeLines(newhdr, "gscoutput.hdr")
# plot the output
R1 <- raster("gscoutput.bsq")
plot(R1)



# ****************************************
#  Second comparison with the landscapemetrics package with the number of pixel values metric.
# Package: landscapemetrics version 1.5.6 (single-core) with the metric "lsm_l_pr" and a 3x3 window size.
#   Notes:
#     -The smallest possible window size (3x3) is used because larger windows run much slower.
#     -The metric (lsm_l_pr) is the number of unique pixel values in a window:
#        https://github.com/r-spatialecology/landscapemetrics/blob/HEAD/vignettes/articles/guide_moving_window.Rmd
#     -Strict comparisons of adjacency metrics are not possible because the available neighbor rules in
#       landscapemetrics are 4- and 8-neighbor, while GraySpatCon always uses 2-neighbor.

library(landscapemetrics)
library(terra)
library(ggplot2)

# Re-create input image files
setwd(workdir)  # see top of script
gscinput_tif <- "gscinput.tif"        # tif with pixel values in [0, 100] with 255=missing. 1990x1289 pixels
R0 <- raster(gscinput_tif)    # for landscapemetrics
plot(R0)

# landscapemetrics parameter lsm_l_pr (number of pixel values)
landscape <- terra::rast(R0)
moving_window <- matrix(1, nrow = 3, ncol = 3)
start_time <- Sys.time()
result <- window_lsm(landscape, window = moving_window, what = c("lsm_l_pr"))
end_time <- Sys.time()
end_time - start_time
# execution time1 is 1.18 hours
# execution time2 is 1.18 hours
# execution time3 is 1.30 hours

# landscapemetrics parameter lsm_l_contag (O'Neill et al original contagion, uses the 1+ formulation)
landscape <- terra::rast(R0)
moving_window <- matrix(1, nrow = 3, ncol = 3)
start_time <- Sys.time()
result <- window_lsm(landscape, window = moving_window, what = c("lsm_l_contag"))
end_time <- Sys.time()
end_time - start_time
# execution time1 is 1.47 hours
# execution time2 is 1.47 hours
# execution time3 is 1.46 hours

# landscapemetrics parameter lsm_l_siei (GS evenness of pixelvalues)
landscape <- terra::rast(R0)
moving_window <- matrix(1, nrow = 3, ncol = 3)
start_time <- Sys.time()
result <- window_lsm(landscape, window = moving_window, what = c("lsm_l_siei"))
end_time <- Sys.time()
end_time - start_time
# execution time1 is >3 hours (terminated at 4.6 hours)
# execution time2 is >3 hours (terminated at 3.1 hours)
# execution time3 is 6.87 hours, so it ran to completion.



# GraySpatCon trials 
#   GSC uses all available cores; un-comment the following line for single-core comparison
#     Sys.setenv("OMP_NUM_THREADS" = 1)
#   On hardware with more than 8 cores, use this to use only 8:
#     Sys.setenv("OMP_NUM_THREADS" = 8)

#   Be sure to later run the following line to restore multi-core usage 
#     Sys.unsetenv("OMP_NUM_THREADS")

# GraySpatCon (single- and eight-core) for metric 19 (number of gray levels) in 3x3 window
#   Defaults to moving window analysis, for global extent analysis replace "G 0" with "G 1"
#     in the third writeLines command below

setwd(workdir)  # see top of script
gscinput_tif <- "gscinput.tif"  # tif with pixel values in [0, 100] with 255=missing. 1990x1289 pixels
R0 <- raster(gscinput_tif)
gdal_translate(gscinput_tif, "gscinput", of="ENVI") # for grayspatcon

# create and write gscpars.txt
file.remove("gscpars.txt") # delete existing parameter file
fileConn <- file("gscpars.txt", "a") # create file connection for appending
writeLines(sprintf("R %d", nrow(R0)), fileConn)
writeLines(sprintf("C %d", ncol(R0)), fileConn)
writeLines(c("F 2", "M 19","G 0", "P 0", "W 3", "A 1", "B 5", "X 88", "Y 87", "K 5"), fileConn)
close(fileConn)

start_time <- Sys.time()
system("grayspatcon64.exe")
end_time <- Sys.time()
end_time - start_time

# execution time
# 8-core:
# execution time1 is 0.16 seconds
# execution time2 is 0.16 seconds
# execution time3 is 0.17 seconds
# 1-core:
# execution time1 is 0.37 seconds
# execution time2 is 0.28 seconds
# execution time2 is 0.40 seconds

# GraySpatCon (single- and eight-core) for metric 2 (EvennessOrderedAdj) does not use 1+ formulation
#   Defaults to moving window analysis, for global extent analysis replace "G 0" with "G 1"
#     in the third writeLines command below
# create and write gscpars.txt
file.remove("gscpars.txt") # delete existing parameter file
fileConn <- file("gscpars.txt", "a") # create file connection for appending
writeLines(sprintf("R %d", nrow(R0)), fileConn)
writeLines(sprintf("C %d", ncol(R0)), fileConn)
writeLines(c("F 2", "M 2","G 0", "P 0", "W 3", "A 1", "B 5", "X 88", "Y 87", "K 5"), fileConn)
close(fileConn)

start_time <- Sys.time()
system("grayspatcon64.exe")
end_time <- Sys.time()
end_time - start_time
# execution time
# 8-core:
# execution time1 is 5.26 seconds
# execution time2 is 5.47 seconds
# execution time3 is 4.87 seconds
# 1-core:
# execution time1 is 19.29 seconds
# execution time2 is 19.41 seconds
# execution time2 is 19.16 seconds


# GraySpatCon (single- and eight-core) for metric 11 (GSEvenness)
#   Defaults to moving window analysis, for global extent analysis replace "G 0" with "G 1"
#     in the third writeLines command below
# create and write gscpars.txt
file.remove("gscpars.txt") # delete existing parameter file
fileConn <- file("gscpars.txt", "a") # create file connection for appending
writeLines(sprintf("R %d", nrow(R0)), fileConn)
writeLines(sprintf("C %d", ncol(R0)), fileConn)
writeLines(c("F 2", "M 11","G 0", "P 0", "W 3", "A 1", "B 5", "X 88", "Y 87", "K 5"), fileConn)
close(fileConn)

start_time <- Sys.time()
system("grayspatcon64.exe")
end_time <- Sys.time()
end_time - start_time
# execution time
# 8-core:
# execution time1 is 0.28 seconds
# execution time2 is 0.29 seconds
# execution time3 is 0.28 seconds
# 1-core:
# execution time1 is 0.49 seconds
# execution time2 is 0.51 seconds
# execution time2 is 0.48 seconds

# ************** end of moving window comparisons *******************

# Compare global extent option in landscapemetrics and GSC
# landscapemetrics parameter lsm_l_contag (O'Neill et al original contagion, uses the 1+ formulation)
landscape <- terra::rast(R0)

# number of pixel values
start_time <- Sys.time()
result <- lsm_l_pr(landscape)
end_time <- Sys.time()
end_time - start_time
# execution time1 is 0.17 seconds
# execution time2 is 0.17 seconds
# execution time3 is 0.19 seconds

# oneill et al contagion
start_time <- Sys.time()
result <- lsm_l_contag(landscape)
end_time <- Sys.time()
end_time - start_time
# execution time1 is 0.36 seconds
# execution time2 is 0.35 seconds
# execution time3 is 0.38 seconds

# GS evenness of pixel values
start_time <- Sys.time()
result <- lsm_l_siei(landscape)
end_time <- Sys.time()
end_time - start_time
# execution time1 is 7.46 seconds
# execution time2 is 7.41 seconds
# execution time3 is 9.46 seconds

# GSC with global option (G=1)
# number of gray levels
# create and write gscpars.txt
file.remove("gscpars.txt") # delete existing parameter file
fileConn <- file("gscpars.txt", "a") # create file connection for appending
writeLines(sprintf("R %d", nrow(R0)), fileConn)
writeLines(sprintf("C %d", ncol(R0)), fileConn)
writeLines(c("F 2", "M 19","G 1", "P 0", "W 3", "A 1", "B 5", "X 88", "Y 87", "K 5"), fileConn)
close(fileConn)

start_time <- Sys.time()
system("grayspatcon64.exe")
end_time <- Sys.time()
end_time - start_time
# execution time1 is 0.18 seconds
# execution time2 is 0.16 seconds
# execution time3 is 0.16 seconds

# GSC with global option (G=1)
# for metric 2 (EvennessOrderedAdj) does not use 1+ formulation
# create and write gscpars.txt
file.remove("gscpars.txt") # delete existing parameter file
fileConn <- file("gscpars.txt", "a") # create file connection for appending
writeLines(sprintf("R %d", nrow(R0)), fileConn)
writeLines(sprintf("C %d", ncol(R0)), fileConn)
writeLines(c("F 2", "M 2","G 1", "P 0", "W 3", "A 1", "B 5", "X 88", "Y 87", "K 5"), fileConn)
close(fileConn)

start_time <- Sys.time()
system("grayspatcon64.exe")
end_time <- Sys.time()
end_time - start_time
# execution time1 is 0.17 seconds
# execution time2 is 0.17seconds
# execution time3 is 0.17 seconds

# GSC with global option (G=1)
# for for metric 11 (GSEvenness)
# create and write gscpars.txt
file.remove("gscpars.txt") # delete existing parameter file
fileConn <- file("gscpars.txt", "a") # create file connection for appending
writeLines(sprintf("R %d", nrow(R0)), fileConn)
writeLines(sprintf("C %d", ncol(R0)), fileConn)
writeLines(c("F 2", "M 11","G 1", "P 0", "W 3", "A 1", "B 5", "X 88", "Y 87", "K 5"), fileConn)
close(fileConn)

start_time <- Sys.time()
system("grayspatcon64.exe")
end_time <- Sys.time()
end_time - start_time
# execution time1 is 0.15 seconds
# execution time2 is 0.17seconds
# execution time3 is 0.16 seconds


# **********End of package comparisons***********