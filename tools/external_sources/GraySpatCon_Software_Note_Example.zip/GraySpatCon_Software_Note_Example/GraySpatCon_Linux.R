# Linux R script to run GraySpatCon
# Kurt Riitters April 2023
#
# This script supports running GraySpatCon with a moving window or global extent analysis.
# To use this script, ensure the following are located in your R working directory
#   - GraySpatCon binary executable file (grayspatcon_lin64; ensure it is executable)
#   - input GeoTIFF image 
# For instructions to obtain test images, the binary executable file, and the GRAYSPATCON_Guide,
#   see the archive file: GraySpatCon_Software_Note_Example.zip,
#   located here: https://github.com/ec-jrc/GWB/blob/main/tools/external_sources/
# 
# Please refer to the GRAYSPATCON_Guide for input GeoTIFF requirements, details on metrics and
#   GraySpatCon parameters, and important usage notes
#
# For a given <input file>, this script will produce either a map (window analysis) or a text file (global analysis)
#   Window analysis: Output maps are named "<input file>_Mff_Wff_Pff_Xff_Yff_Kff>.tif" 
#   Global analysis: Output text files are named "<input file>_Mff_Wff_Pff_Xff_Yff_Kff>.txt" 
#   where "ff" represents the user-specified parameter values (see below)
#
library(terra)
library(gdalUtilities)
# Edit this code block to specify working directory, input file, and run parameters
# *****************************************************
workdir <- "~/R-code"    # specify your working directory which contains the binary executable and input data

gscinput_tif <- "gscinput.tif"        # tif with pixel values in [0, 100] with 255=missing. 1990x1289 pixels
# gscinput_tif <- "clc3class.tif"       # tif with pixel values 1,2,3 only. 2000x2000 pixels

# GraySpatCon parameters. Edit but do not delete any of these
# Required:
Mpar <- 32 # M parameter is the metric number
Wpar <- 31 # W parameter is the window side length; moving window size = W x W
Gpar <- 0  # G=0 for moving window, or G=1 for global extent
# Optional:
Ppar <- 0  # P parameter; 1 = exclude input zero values, 0 = do not exclude them
# Required for some metrics; ignored for other metrics:
Xpar <- 88 # X parameter is needed only for metrics 21, 22, 23, 24
Ypar <- 87 # Y parameter is needed only for metrics 23,24
Kpar <- 4 # K parameter is needed only for metric 49
# *********Do not edit below this line**************
setwd(workdir)  

# Get the map, plot it, and convert the disk file from GeoTIFF to BSQ named "gscinput" (no extension)
R0 <- rast(gscinput_tif)
plot(R0)
gdal_translate(gscinput_tif, "gscinput", of="ENVI")  # this also writes an envi-style header file (gscinput.hdr) that will be used later.

# Create parameter file for GraySpatCon 
file.remove("gscpars.txt") # delete existing parameter file
fileConn <- file("gscpars.txt", "a") # create file connection for appending
writeLines(sprintf("R %d", nrow(R0)), fileConn)
writeLines(sprintf("C %d", ncol(R0)), fileConn)
writeLines(sprintf("M %d", Mpar), fileConn)
writeLines(sprintf("W %d", Wpar), fileConn)
writeLines(sprintf("G %d", Gpar), fileConn)
writeLines(sprintf("P %d", Ppar), fileConn)
writeLines(sprintf("X %d", Xpar), fileConn)
writeLines(sprintf("Y %d", Ypar), fileConn)
writeLines(sprintf("K %d", Kpar), fileConn)
# For this R script, do not change the following GraySpatCon parameters
#   which specify the options for output map precision, nodata masking, and re-scaling
writeLines(c("F 2", "A 1", "B 1"), fileConn) 
close(fileConn)

# Execute GraySpatCon. GSC will write information/error messages in the console window.
ret_val <- system("./grayspatcon_lin64")
if(ret_val != 0L){
  print("Error: the binary file grayspatcon64.exe was not found or not run")
}
# Post-process either map or text output
if(Gpar == 1) { # text output for global analysis
  old <- c("gscoutput.txt")
  new <- sprintf("%s_M%d_W%d_P%d_X%d_Y%d_K%d.txt", gscinput_tif, Mpar, Wpar, Ppar, Xpar, Ypar, Kpar)
  new <- gsub(pattern = ".tif_", replace = "_", x = new)
  file.rename(old, new)
}
if(Gpar == 0) { # map output for window analysis
  
  # Convert output file to GeoTIFF: rename output file, copy/edit header file, create GeoTIFF using appropriate nodata values
  
  # Rename output file
  old <- c("gscoutput")
  new <- c("gscoutput.bsq")
  file.rename(old, new)
  
  # Copy and edit the input BSQ header file. This is an ENVI-style header.
  # To support GraySpatCon float output, change the data type from 1 (byte) to 4 (float).
  oldhdr <- readLines("gscinput.hdr")
  newhdr <- gsub(pattern = "data type = 1", replace = "data type = 4", x = oldhdr)
  writeLines(newhdr, "gscoutput.hdr")
  
  # Convert the disk file from BSQ to GeoTIFF, using metric-dependent nodata value
  if(Mpar == 44 || Mpar==45 || Mpar==50) {
    gdal_translate("gscoutput.bsq", "gscoutput.tif", of="Gtiff", a_nodata = -9000000.0)
  } else {
    gdal_translate("gscoutput.bsq", "gscoutput.tif", of="Gtiff", a_nodata = -0.01)
  }
  
  # Plot the output GeoTIFF
  R1 <- rast("gscoutput.tif")
  plot(R1)
  
  # rename output tif file name to include the parameter values
  old <- c("gscoutput.tif")
  new <- sprintf("%s_M%d_W%d_P%d_X%d_Y%d_K%d.tif", gscinput_tif, Mpar, Wpar, Ppar, Xpar, Ypar, Kpar)
  new <- gsub(pattern = ".tif_", replace = "_", x = new)
  file.rename(old, new)
  
  # Clean up temporary disk files
  file.remove("gscoutput.bsq")
  file.remove("gscoutput.hdr")
  file.remove("gscinput.hdr")
}
#
#
# ***************end of R script to test metrics**********************
#
# Other GraySpatCon parameters are hard-wired for this example script; this script does not support using them
#   (These parameters are easily tested using GuidosToolBox):
#   Do not select global analysis (G parameter = 0)
#   Output map is type float (F parameter = 2)
#   Output is masked to the non-missing input data (A parameter = 1)
#   The B parameter is ignored when output data type is float; see GSC Guide for options
#