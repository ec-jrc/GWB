# Linux R script to run GraySpatCon (top part) and compare with several R modules (bottom part)
# Kurt Riitters April 2023
#
# This script supports running GraySpatCon metrics with a moving window analysis, with user-specified
#   input GeoTIFF image, window size, and choice of including/excluding pixel values which are zero, with
#   display of the output geoTIFF image.
# Other GraySpatCon parameters are hard-wired in this version. They can be exercised using the 
#   GuidosToolBox as described in the GSC Guide
#
# The reported comparisons with other R packages used the code at the bottom of this script.
#   If you know of other comparable packages, or if your comparisons differ substantially
#   or are otherwise interesting please let the author know.
#
# To use this script, ensure the following are located in your R working directory
#   - GraySpatCon binary executable file
#   - input GeoTIFF image (see Guide for requirements)
# For instructions to obtain test images and binary executable files see the readme.txt file in this archive:
# https://github.com/ec-jrc/GWB/blob/main/tools/external_sources/GraySpatCon_Software_Note_Example.zip
# 
# The output GeoTIFF image is named <input file>_Mx_Wy_Pz>.tif where x,y,z are the user-selected values for the M,W,P parameters
#
# Then, edit the following lines to specify directory, file name, and run parameters 
# *****************************************************
# local directory
workdir <- "~/R-code"    # specify working directory
#
# The default settings for gscinput_tif ("gscinput.tif"), Mpar (32), Wpar (31),
#   and Ppar (0) will replicate the example in Table 3 of the software note.
#
# input data image (two examples provided with this script)
gscinput_tif <- "gscinput.tif"        # tif with pixel values in [0, 100] with 255=missing. 1990x1289 pixels
# gscinput_tif <- "clc3class.tif"       # tif with pixel values 1,2,3 only. 2000x2000 pixels

# GraySpatCon parameters. Edit but do not delete any of these
# Required:
Mpar <- 32 # M parameter is the metric number
Wpar <- 31 # W parameter is the window side length; moving window size = W x W
# Optional:
Ppar <- 0  # P parameter; 1 = exclude input zero values, 0 = do not exclude them
# Required for some metrics; ignored for other metrics:
Xpar <- 88 # X parameter is needed only for metrics 21, 22, 23, 24
Ypar <- 87 # Y parameter is needed only for metrics 23,24
Kpar <- 4 # K parameter is needed only for metric 49
#
#   Other GraySpatCon parameters are hard-wired for this example script; this script does not support using them:
#   Do not select global analysis (G parameter = 0)
#   Output map is type float (F parameter = 2)
#   Output is masked to the non-missing input data (A parameter = 1)
#   The B parameter is ignored when output data type is float; see GSC Guide for options
#
# *********Do not edit below this line**************
library(sp)
library(raster)
library(gdalUtilities)

setwd(workdir)  
R0 <- raster(gscinput_tif)
plot(R0)

# create parameter file for GraySpatCon 
file.remove("gscpars.txt") # delete existing parameter file
fileConn <- file("gscpars.txt", "a") # create file connection for appending
writeLines(sprintf("R %d", nrow(R0)), fileConn)
writeLines(sprintf("C %d", ncol(R0)), fileConn)
writeLines(sprintf("M %d", Mpar), fileConn)
writeLines(sprintf("W %d", Wpar), fileConn)
writeLines(sprintf("P %d", Ppar), fileConn)
writeLines(sprintf("X %d", Xpar), fileConn)
writeLines(sprintf("Y %d", Ypar), fileConn)
writeLines(sprintf("K %d", Kpar), fileConn)
# for this R script, do not change the following GraySpatCon parameters
writeLines(c("F 2", "G 0", "A 1", "B 1"), fileConn) 
close(fileConn)

# minimal check for valid geotiff input image here; GraySpatCon may catch/report other issues.
prj <<- projection(R0)
if (is.na(prj)) print("---------Warning: The input image has no projection and is not a geoTIFF.---------")
if (R0@file@nbands != 1) print("---------Warning: The input image is not a single band image.---------")
bandtype <- dataType(R0)
if (bandtype != "INT1U") print("---------Warning: The input image is not unsigned byte value---------")

# convert to bsq format with no extension: "gscinput"
gdal_translate(gscinput_tif, "gscinput", of="ENVI")  # this also produces an envi-style header file (gscinput.hdr)

# execute GraySpatCon 
start_time <- Sys.time()
system("./grayspatcon_lin64") # ensure the binary is executable
end_time <- Sys.time()
end_time - start_time

# convert output to geotif format

# rename output file
old <- c("gscoutput")
new <- c("gscoutput.bsq")
file.rename(old, new)

# copy and edit old header file. This is an ENVI-style header.To support GraySpatCon float output,
#   only the data type needs to be changed from 1 (byte) to 4 (float).
#   The projection info is contained in the input ENVI header and used without modification.
oldhdr <- readLines("gscinput.hdr")
newhdr <- gsub(pattern = "data type = 1", replace = "data type = 4", x = oldhdr)
writeLines(newhdr, "gscoutput.hdr")

#  create a tif from bsq, using the nodata value appropriate for the selected metric 
if(Mpar == 44 || Mpar==45 || Mpar==50) {
  gdal_translate("gscoutput.bsq", "gscoutput.tif", of="Gtiff", a_nodata = -9000000.0)
} else {
  gdal_translate("gscoutput.bsq", "gscoutput.tif", of="Gtiff", a_nodata = -0.01)
}
# the output file is "gscoutput.tif" in the working directory
# visualize the tif output in R
R1 <- raster("gscoutput.tif")
plot(R1)

# rename output tif file <input file>_Mx_Wy_Pz>.tif where x,y,z are the M,W,P parameters
old <- c("gscoutput.tif")
new <- sprintf("%s_M%d_W%d_P%d.tif", gscinput_tif, Mpar, Wpar, Ppar)
new <- gsub(pattern = ".tif_", replace = "_", x = new)
file.rename(old, new)
#
#
# ***************end of R script to test metrics**********************
#
#
#
#
# ***************script to compare with other R packages**************
# The execution times are from the author's platform:
# PCLinuxOS release 2023 64-bit. Kernel Linux 5.2.15-pclos1 x86_64.
# Dual quad-core AMD Opteron 6308 (Abu Dhabi) with 256GB RAM.
# RStudio 2023.03.0 Build 386 "Cherry Blossom" 
# R version 4.2.3 (2023-03-15) "Shortstop Beagle"; packages updated April 17, 2023
#
# Un-comment the following lines as needed
#
# # Package: glcm (single-core) with the metric "homogeneity" and 31x31 window size
# library(glcm)
# # Re-create input image files
# setwd(workdir)  # see top of script
# gscinput_tif <- "gscinput.tif"  # tif with pixel values in [0, 100] with 255=missing. 1990x1289 pixels
# R0 <- raster(gscinput_tif)  # for glcm
# plot(R0)
# 
# start_time <- Sys.time()
# glcm_homogeneity <-   # shift 0,-1 and 1,0 is one down and one right, like GraySpatCon
#   glcm(R0, n_grey = 101, window = c(31, 31), shift = list(c(0,-1), c(1,0)),
#        # statistics = c("mean", "variance", "homogeneity", "contrast", 
#        #               "dissimilarity", "entropy", "second_moment", "correlation"),
#        statistics = c("homogeneity"),
#        min_x=NULL, max_x=NULL, na_opt="any", na_val=NA, scale_factor=1, asinteger=FALSE)
# end_time <- Sys.time()
# end_time - start_time
# # execution time1 is 3.24 minutes
# # execution time2 is 3.24 minutes
# # execution time2 is 3.26 minutes
# 
# plot(glcm_homogeneity) # note the output image is trimmed -- glcm produces missing data where a  window contains any missing data.
#  
# #Package: fastGLCM (multi-core) with the metric "homogeneity", kernel_size 31 (x31) "levels" = 8 (per manual)
# library(fastGLCM)
# library(OpenImageR)
# library(utils)
# 
# setwd(workdir) 
# im = readImage("gscinput.tif")  # Note openImageR does not recognize tags needed for geoTIFF support
# # use openImageR functions to get correct image format
# dims <- dim(im)
# im=resizeImage(im,dims[1],dims[2],'nearest') 
# im=OpenImageR::norm_matrix_range(im,0,255)
# imageShow(im)
# #methods=c('mean', 'std', 'contrast', 'dissimilarity', 'homogeneity', 'ASM', 'energy', 'max', 'entropy')
# methods=c('homogeneity')
# start_time <- Sys.time()
# res_glcm = fastGLCM_Rcpp(data = im, methods = methods, levels = 8, kernel_size = 31,
#                          distance = 1.0, angle = 0.0,  threads = 1, verbose = TRUE)
# end_time <- Sys.time()
# end_time - start_time
# # 8 core
# # execution time1 is 23.06 seconds
# # execution time2 is 23.20 seconds
# # execution time2 is 23.80 seconds
# # 1 core
# # execution time1 is 2.57 minutes
# # execution time2 is 2.53 minutes
# # execution time2 is 2.55 minutes
# 
# str(res_glcm)
# plot_multi_images(list_images = res_glcm, par_ROWS = 1, par_COLS = 1, titles = methods)      
# 
# 
# 
# 
# 
# 
# # GraySpatCon (single- and eight-core) for metric 32 (homogeneity) in 31x31 window
# #   GSC uses all available cores; un-comment the following line for single-core comparison
# #     Sys.setenv("OMP_NUM_THREADS" = 1)
# #   Be sure to later run the following line to restore multi-core usage
# #     Sys.unsetenv("OMP_NUM_THREADS")
# setwd(workdir)  # see top of script
# gscinput_tif <- "gscinput.tif"  # tif with pixel values in [0, 100] with 255=missing. 1990x1289 pixels
# R0 <- raster(gscinput_tif)  
# gdal_translate(gscinput_tif, "gscinput", of="ENVI") # for GraySpatCon
# 
# # create parameter file to duplicate the glcm run
# file.remove("gscpars.txt") # delete existing parameter file
# fileConn <- file("gscpars.txt", "a") # create file connection for appending
# writeLines(sprintf("R %d", nrow(R0)), fileConn)
# writeLines(sprintf("C %d", ncol(R0)), fileConn)
# writeLines(c("F 2", "M 32","G 0", "P 0", "W 31", "A 1", "B 5", "X 88", "Y 87", "K 5"), fileConn)
# close(fileConn)
# 
# start_time <- Sys.time()
# system("./grayspatcon_lin64")
# end_time <- Sys.time()
# end_time - start_time
# # 8-core:
# # execution time1 is 5.74 seconds 
# # execution time2 is 5.57 seconds 
# # 1-core:
# # execution time1 is 29.56 seconds 
# # execution time2 is 29.53 seconds 
# 
# # rename output file
# old <- c("gscoutput")
# new <- c("gscoutput.bsq")
# file.rename(old, new)
# # copy and edit old header file.
# oldhdr <- readLines("gscinput.hdr")
# newhdr <- gsub(pattern = "data type = 1", replace = "data type = 4", x = oldhdr)
# writeLines(newhdr, "gscoutput.hdr")
# # plot the output
# R1 <- raster("gscoutput.bsq")
# plot(R1)
# 
# # ****************************************
# #  Second comparison with the landscapemetrics package with the number of pixel values metric.
# # Package: landscapemetrics (single-core) with the metric "lsm_l_pr" and a 3x3 window size.
# #   Notes:
# #     -The smallest possible window size (3x3) is used because larger windows run much slower.
# #     -The metric (lsm_l_pr) is the number of unique pixel values in a window:
# #        https://github.com/r-spatialecology/landscapemetrics/blob/HEAD/vignettes/articles/guide_moving_window.Rmd
# #     -Strict comparisons of adjacency metrics are not possible because the available neighbor rules in
# #       landscapemetrics are 4- and 8-neighbor, while GraySpatCon always uses 2-neighbor.
# 
# library(landscapemetrics)
# library(terra)
# library(ggplot2)
# 
# # Re-create input image files
# setwd(workdir)  # see top of script
# gscinput_tif <- "gscinput.tif"        # tif with pixel values in [0, 100] with 255=missing. 1990x1289 pixels
# R0 <- raster(gscinput_tif)    # for landscapemetrics
# plot(R0)
# 
# # landscapemetrics parameter lsm_l_pr (number of pixel values)
# landscape <- terra::rast(R0)
# moving_window <- matrix(1, nrow = 3, ncol = 3)  
# start_time <- Sys.time()
# result <- window_lsm(landscape, window = moving_window, what = c("lsm_l_pr"))
# end_time <- Sys.time()
# end_time - start_time
# # execution time1 is 1.33 hours
# # execution time2 is 1.34 hours
# 
# 
# # GraySpatCon (single- and eight-core) for metric 19 (number of gray levels) in 3x3 window
# #   GSC uses all available cores; un-comment the following line for single-core comparison
# #     Sys.setenv("OMP_NUM_THREADS" = 1)
# #   Be sure to later run the following line to restore multi-core usage
# #     Sys.unsetenv("OMP_NUM_THREADS")
# 
# setwd(workdir)  # see top of script
# gscinput_tif <- "gscinput.tif"  # tif with pixel values in [0, 100] with 255=missing. 1990x1289 pixels
# R0 <- raster(gscinput_tif)    
# gdal_translate(gscinput_tif, "gscinput", of="ENVI") # for grayspatcon
# 
# # create and write gscpars.txt
# file.remove("gscpars.txt") # delete existing parameter file
# fileConn <- file("gscpars.txt", "a") # create file connection for appending
# writeLines(sprintf("R %d", nrow(R0)), fileConn)
# writeLines(sprintf("C %d", ncol(R0)), fileConn)
# writeLines(c("F 2", "M 19","G 0", "P 0", "W 3", "A 1", "B 5", "X 88", "Y 87", "K 5"), fileConn)
# close(fileConn)
# 
# start_time <- Sys.time()
# system("./grayspatcon_lin64")
# end_time <- Sys.time()
# end_time - start_time
# 
# # execution time
# # 8-core:
# # execution time1 is 0.09 seconds 
# # execution time2 is 0.09 seconds 
# # 1-core:
# # execution time1 is 0.23 seconds 
# # execution time2 is 0.24 seconds 
# # **********End of package comparisons***********